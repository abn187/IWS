      <hr>

      <p class="text-center">Copyright Jacurtis - All Rights Reserved</p>